# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [1.0.0] - 2026-10-06

### Added
- Azure Resource Group child module.
- KaaS resource-group naming validation.
- Azure Government location validation.
- Required `environment` and `managed_by` tag validation.
- Resource Group ID, name, and location outputs.
- Basic and complete examples.
- Terratest integration coverage.
- Architecture diagram and module documentation.
