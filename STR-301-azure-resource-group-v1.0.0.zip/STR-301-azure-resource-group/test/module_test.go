package test

import (
	"fmt"
	"strings"
	"testing"
	"time"

	"github.com/gruntwork-io/terratest/modules/azure"
	"github.com/gruntwork-io/terratest/modules/random"
	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func uniqueRGName(prefix string) string {
	suffix := strings.ToLower(random.UniqueId())
	return fmt.Sprintf("kaas-cdp-dev-%s-%s-va-rg", prefix, suffix)
}

func TestBasicExample(t *testing.T) {
	t.Parallel()

	name := uniqueRGName("basic")
	location := "usgovvirginia"
	tags := map[string]string{
		"environment": "dev",
		"purpose":     "platform",
		"managed_by":  "terraform",
	}

	options := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		TerraformDir: "../examples/basic",
		Vars: map[string]interface{}{
			"name":     name,
			"location": location,
			"tags":     tags,
		},
	})

	defer terraform.Destroy(t, options)
	terraform.InitAndApply(t, options)

	assert.Equal(t, name, terraform.Output(t, options, "name"))
	assert.Equal(t, location, strings.ToLower(terraform.Output(t, options, "location")))

	subscriptionID := azure.GetSubscriptionIDFromURLEnv(t)
	actualTags := azure.GetTagsForResourceGroup(t, name, subscriptionID)
	for key, expected := range tags {
		assert.Equal(t, expected, actualTags[key])
	}
}

func TestCompleteExample(t *testing.T) {
	t.Parallel()

	first := uniqueRGName("completea")
	second := uniqueRGName("completeb")
	location := "usgovvirginia"

	resourceGroups := map[string]interface{}{
		"platform": map[string]interface{}{
			"name":     first,
			"location": location,
			"tags": map[string]string{
				"environment": "dev",
				"tenant":      "cdp",
				"component":   "platform",
				"esats_id":    "test-esats",
				"finops_uuid": "test-finops",
				"managed_by":  "terraform",
			},
		},
		"observability": map[string]interface{}{
			"name":     second,
			"location": location,
			"tags": map[string]string{
				"environment": "dev",
				"tenant":      "cdp",
				"component":   "observability",
				"esats_id":    "test-esats",
				"finops_uuid": "test-finops",
				"managed_by":  "terraform",
			},
		},
	}

	options := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		TerraformDir: "../examples/complete",
		Vars: map[string]interface{}{
			"resource_groups": resourceGroups,
		},
		MaxRetries:         3,
		TimeBetweenRetries: 10 * time.Second,
	})

	defer terraform.Destroy(t, options)
	terraform.InitAndApply(t, options)

	output := terraform.OutputMapOfObjects(t, options, "resource_groups")
	require.Contains(t, output, "platform")
	require.Contains(t, output, "observability")

	subscriptionID := azure.GetSubscriptionIDFromURLEnv(t)
	for _, name := range []string{first, second} {
		assert.True(t, azure.ResourceGroupExists(t, name, subscriptionID))
		actualTags := azure.GetTagsForResourceGroup(t, name, subscriptionID)
		assert.Equal(t, "dev", actualTags["environment"])
		assert.Equal(t, "terraform", actualTags["managed_by"])
	}
}
