module github.com/kaas/azure-resource-group/test

go 1.22

require github.com/gruntwork-io/terratest v0.48.2
