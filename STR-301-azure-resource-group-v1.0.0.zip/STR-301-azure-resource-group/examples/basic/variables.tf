variable "name" {
  description = "Resource Group name."
  type        = string
  default     = "kaas-cdp-dev-platform-va-rg"
}

variable "location" {
  description = "Azure Government region."
  type        = string
  default     = "usgovvirginia"
}

variable "tags" {
  description = "Resource Group tags."
  type        = map(string)
  default = {
    environment = "dev"
    purpose     = "platform"
    managed_by  = "terraform"
  }
}
