output "id" {
  description = "Resource Group ID."
  value       = module.platform_rg.id
}

output "name" {
  description = "Resource Group name."
  value       = module.platform_rg.name
}

output "location" {
  description = "Resource Group location."
  value       = module.platform_rg.location
}
