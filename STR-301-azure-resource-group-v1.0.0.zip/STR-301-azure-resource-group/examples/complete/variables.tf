variable "resource_groups" {
  description = "Map of Resource Groups to create."
  type = map(object({
    name     = string
    location = string
    tags     = map(string)
  }))

  default = {
    platform = {
      name     = "kaas-cdp-dev-platform-va-rg"
      location = "usgovvirginia"
      tags = {
        environment = "dev"
        tenant      = "cdp"
        component   = "platform"
        esats_id    = "example-esats"
        finops_uuid = "example-finops"
        purpose     = "platform"
        managed_by  = "terraform"
      }
    }

    observability = {
      name     = "kaas-cdp-dev-observability-va-rg"
      location = "usgovvirginia"
      tags = {
        environment = "dev"
        tenant      = "cdp"
        component   = "observability"
        esats_id    = "example-esats"
        finops_uuid = "example-finops"
        purpose     = "observability"
        managed_by  = "terraform"
      }
    }
  }
}
