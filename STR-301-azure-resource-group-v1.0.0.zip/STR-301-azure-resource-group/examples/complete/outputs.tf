output "resource_groups" {
  description = "Created Resource Groups keyed by input key."
  value = {
    for key, rg in module.resource_groups : key => {
      id       = rg.id
      name     = rg.name
      location = rg.location
    }
  }
}
