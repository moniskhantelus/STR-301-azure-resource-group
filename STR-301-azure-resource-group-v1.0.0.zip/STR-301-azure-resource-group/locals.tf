locals {
  required_tag_keys = toset([
    "environment",
    "managed_by",
  ])

  # Normalize tag keys to lowercase for validation while preserving caller values.
  normalized_tag_keys = toset([for key in keys(var.tags) : lower(key)])

  tags = var.tags
}
