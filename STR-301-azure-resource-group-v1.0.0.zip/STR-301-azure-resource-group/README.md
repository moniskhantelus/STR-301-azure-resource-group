# Azure Resource Group Terraform Module

Reusable KaaS Terraform child module for provisioning Azure Resource Groups with platform naming, Azure Government location validation, required tagging, and consistent outputs.

## STR-301 requirements implemented

- Creates one Azure Resource Group.
- Restricts `location` to `usgovvirginia`, `usgovarizona`, or `usgovtexas`.
- Enforces a KaaS-style lower-case resource-group name beginning with `kaas-` and ending in `-rg`.
- Requires the `environment` and `managed_by` tags.
- Exposes `id`, `name`, and `location`.
- Includes deployable basic and complete examples.
- Includes Terratest coverage for both examples.

### Tag requirement note

STR-301's Required Variables section describes the tag map as including `environment`, `tenant`, `component`, `esats_id`, `finops_uuid`, and `managed_by`, while its explicit Validation Requirements and example usage require only `environment` and `managed_by`. This module therefore **enforces the two explicitly mandatory validation tags** and supports the additional governance tags without forcing values that are not applicable to every Resource Group. The complete example demonstrates all listed governance tags.

## Usage

```hcl
module "platform_rg" {
  source = "git::https://gitlab.example.com/kaas/catalog/azure/azure_resource_group.git?ref=v1.0.0"

  name     = "kaas-cdp-dev-platform-va-rg"
  location = "usgovvirginia"

  tags = {
    environment = "dev"
    purpose     = "platform"
    managed_by  = "terraform"
  }
}
```

## Requirements

| Name | Version |
|------|---------|
| terraform | >= 1.6.0, < 2.0.0 |
| azurerm | >= 4.0, < 5.0 |

## Inputs

| Name | Description | Type | Required |
|------|-------------|------|:--------:|
| name | Full Azure Resource Group name following KaaS naming rules | `string` | yes |
| location | Azure Government region | `string` | yes |
| tags | Tags; `environment` and `managed_by` are mandatory | `map(string)` | yes |

## Outputs

| Name | Description |
|------|-------------|
| id | Full Resource Group resource ID |
| name | Resource Group name |
| location | Resource Group Azure region |

## Examples

- `examples/basic` — one platform Resource Group.
- `examples/complete` — multiple Resource Groups using `for_each`.

## Testing

Terratest is under `test/`.

Set Azure Government authentication/environment variables before running integration tests. For example, use an authenticated Azure CLI session in AzureUSGovernment and set `ARM_SUBSCRIPTION_ID` as required by the AzureRM provider.

```bash
cd test
go mod tidy
go test -v -timeout 45m
```

## terraform-docs

The README input/output sections are compatible with `terraform-docs`. A pipeline can regenerate documentation using the repository's standard terraform-docs configuration.

## Versioning

Initial release target: `v1.0.0`.
