variable "name" {
  description = "Full Azure Resource Group name. Must follow the KaaS resource group naming convention and end in -rg."
  type        = string

  validation {
    condition     = can(regex("^kaas-[a-z0-9]+(?:-[a-z0-9]+)*-rg$", var.name))
    error_message = "name must start with 'kaas-', contain only lowercase letters, numbers, and hyphens, and end with '-rg'. Example: kaas-cdp-prod-platform-va-rg."
  }

  validation {
    condition     = length(var.name) >= 5 && length(var.name) <= 90
    error_message = "name must be between 5 and 90 characters, consistent with Azure Resource Group naming limits."
  }
}

variable "location" {
  description = "Azure Government region in which the Resource Group is created."
  type        = string

  validation {
    condition = contains([
      "usgovvirginia",
      "usgovarizona",
      "usgovtexas",
    ], lower(var.location))
    error_message = "location must be one of: usgovvirginia, usgovarizona, usgovtexas."
  }
}

variable "tags" {
  description = "Tags applied to the Resource Group. environment and managed_by are mandatory. Platform/application callers should also supply applicable governance tags such as tenant, component, esats_id, and finops_uuid."
  type        = map(string)

  validation {
    condition = alltrue([
      contains([for key in keys(var.tags) : lower(key)], "environment"),
      contains([for key in keys(var.tags) : lower(key)], "managed_by"),
    ])
    error_message = "tags must contain the required keys 'environment' and 'managed_by'."
  }

  validation {
    condition     = alltrue([for value in values(var.tags) : length(trimspace(value)) > 0])
    error_message = "tag values must not be empty."
  }
}
