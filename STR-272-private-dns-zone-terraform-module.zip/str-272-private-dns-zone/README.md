# STR-272 — Azure Private DNS Zone Terraform Module

Reusable Terraform module for Azure Private DNS zones.

## Story basis

The supplied Jira export identifies **STR-272** as **Private DNS Zone Terraform Module**. It is linked to be completed after **STR-52 — Private DNS Configuration** and belongs to the **IaC Foundation Cluster Provisioning** epic. The exported Jira Description is blank, so implementation details below are intentionally treated as module design assumptions rather than story requirements.

## Capabilities

- Create a Private DNS zone or reuse an existing zone.
- Link one or more VNets.
- Configure `registration_enabled` per VNet link.
- Manage A, AAAA, CNAME, TXT, MX and SRV records.
- Optionally override the SOA record for a newly created zone.
- Apply tags to the zone and VNet links.
- Return zone, VNet-link and common record IDs.
- Stable `for_each` keys avoid index-based resource churn.

## Requirements

- Terraform >= 1.6
- AzureRM provider >= 3.100 and < 5.0
- Caller must configure the AzureRM provider and have permissions on the target resource group / VNet scope.

## Basic usage

```hcl
module "private_dns" {
  source = "../../"

  name                = "privatelink.blob.core.windows.net"
  resource_group_name = "rg-platform-dns"

  virtual_network_links = {
    platform = {
      name                 = "platform-vnet-link"
      virtual_network_id   = "/subscriptions/.../resourceGroups/.../providers/Microsoft.Network/virtualNetworks/vnet-platform"
      registration_enabled = false
    }
  }
}
```

## Reuse an existing zone

```hcl
module "private_dns" {
  source = "../../"

  create_zone         = false
  name                = "privatelink.vaultcore.azure.net"
  resource_group_name = "rg-shared-dns"

  virtual_network_links = {
    workload = {
      virtual_network_id = "/subscriptions/.../virtualNetworks/vnet-workload"
    }
  }
}
```

## Design notes

`registration_enabled` should normally remain `false` for Azure Private Link zones. Set it to `true` only when automatic VM hostname registration is actually intended.

This module deliberately does not create VNets, Private Endpoints, Private DNS Zone Groups, DNS Private Resolver resources, RBAC assignments, or resource groups. Those concerns should remain in their owning modules unless STR-272 is expanded with explicit requirements.

## Validation

Run:

```bash
terraform fmt -recursive -check
terraform init -backend=false
terraform validate
tflint --recursive
```

See `examples/basic` and `examples/complete`.
