resource "azurerm_private_dns_zone" "this" {
  count = var.create_zone ? 1 : 0

  name                = var.name
  resource_group_name = var.resource_group_name
  tags                = var.tags

  dynamic "soa_record" {
    for_each = var.soa_record == null ? [] : [var.soa_record]
    content {
      email        = soa_record.value.email
      expire_time  = soa_record.value.expire_time
      minimum_ttl  = soa_record.value.minimum_ttl
      refresh_time = soa_record.value.refresh_time
      retry_time   = soa_record.value.retry_time
      ttl          = soa_record.value.ttl
    }
  }
}

data "azurerm_private_dns_zone" "this" {
  count = var.create_zone ? 0 : 1

  name                = var.name
  resource_group_name = var.resource_group_name
}

locals {
  zone = var.create_zone ? azurerm_private_dns_zone.this[0] : data.azurerm_private_dns_zone.this[0]

  virtual_network_links = {
    for key, link in var.virtual_network_links : key => merge(link, {
      effective_name = coalesce(link.name, key)
    })
  }
}

resource "azurerm_private_dns_zone_virtual_network_link" "this" {
  for_each = local.virtual_network_links

  name                  = each.value.effective_name
  resource_group_name   = var.resource_group_name
  private_dns_zone_name = local.zone.name
  virtual_network_id    = each.value.virtual_network_id
  registration_enabled  = each.value.registration_enabled
  tags                  = each.value.tags

  depends_on = [azurerm_private_dns_zone.this]
}

resource "azurerm_private_dns_a_record" "this" {
  for_each = var.a_records

  name                = each.value.name
  zone_name           = local.zone.name
  resource_group_name = var.resource_group_name
  ttl                 = each.value.ttl
  records             = each.value.records

  depends_on = [azurerm_private_dns_zone.this]
}

resource "azurerm_private_dns_aaaa_record" "this" {
  for_each = var.aaaa_records

  name                = each.value.name
  zone_name           = local.zone.name
  resource_group_name = var.resource_group_name
  ttl                 = each.value.ttl
  records             = each.value.records

  depends_on = [azurerm_private_dns_zone.this]
}

resource "azurerm_private_dns_cname_record" "this" {
  for_each = var.cname_records

  name                = each.value.name
  zone_name           = local.zone.name
  resource_group_name = var.resource_group_name
  ttl                 = each.value.ttl
  record              = each.value.record

  depends_on = [azurerm_private_dns_zone.this]
}

resource "azurerm_private_dns_txt_record" "this" {
  for_each = var.txt_records

  name                = each.value.name
  zone_name           = local.zone.name
  resource_group_name = var.resource_group_name
  ttl                 = each.value.ttl

  dynamic "record" {
    for_each = each.value.records
    content {
      value = record.value
    }
  }

  depends_on = [azurerm_private_dns_zone.this]
}

resource "azurerm_private_dns_mx_record" "this" {
  for_each = var.mx_records

  name                = each.value.name
  zone_name           = local.zone.name
  resource_group_name = var.resource_group_name
  ttl                 = each.value.ttl

  dynamic "record" {
    for_each = each.value.records
    content {
      preference = record.value.preference
      exchange   = record.value.exchange
    }
  }

  depends_on = [azurerm_private_dns_zone.this]
}

resource "azurerm_private_dns_srv_record" "this" {
  for_each = var.srv_records

  name                = each.value.name
  zone_name           = local.zone.name
  resource_group_name = var.resource_group_name
  ttl                 = each.value.ttl

  dynamic "record" {
    for_each = each.value.records
    content {
      priority = record.value.priority
      weight   = record.value.weight
      port     = record.value.port
      target   = record.value.target
    }
  }

  depends_on = [azurerm_private_dns_zone.this]
}
