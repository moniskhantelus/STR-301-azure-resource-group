variable "zone_name" {
  type    = string
  default = "internal.example.com"
}

variable "resource_group_name" {
  type = string
}

variable "hub_virtual_network_id" {
  type = string
}

variable "spoke_virtual_network_id" {
  type = string
}

variable "tags" {
  type    = map(string)
  default = {}
}
