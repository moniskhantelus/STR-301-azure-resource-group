output "zone_id" {
  value = module.private_dns.id
}

output "vnet_link_ids" {
  value = module.private_dns.virtual_network_link_ids
}
