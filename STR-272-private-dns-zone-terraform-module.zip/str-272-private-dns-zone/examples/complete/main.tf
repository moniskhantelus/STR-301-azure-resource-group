terraform {
  required_version = ">= 1.6.0"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 3.100, < 5.0"
    }
  }
}

provider "azurerm" {
  features {}
}

module "private_dns" {
  source = "../../"

  name                = var.zone_name
  resource_group_name = var.resource_group_name
  create_zone         = true

  virtual_network_links = {
    hub = {
      name                 = "hub-link"
      virtual_network_id   = var.hub_virtual_network_id
      registration_enabled = false
      tags                 = var.tags
    }
    spoke = {
      name                 = "spoke-link"
      virtual_network_id   = var.spoke_virtual_network_id
      registration_enabled = false
      tags                 = var.tags
    }
  }

  a_records = {
    example = {
      name    = "app"
      ttl     = 300
      records = ["10.10.10.10"]
    }
  }

  cname_records = {
    alias = {
      name   = "service"
      ttl    = 300
      record = "app.${var.zone_name}"
    }
  }

  txt_records = {
    metadata = {
      name    = "metadata"
      ttl     = 300
      records = [["managed-by=terraform"]]
    }
  }

  tags = var.tags
}
