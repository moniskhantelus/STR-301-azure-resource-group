output "private_dns_zone_id" {
  value = module.private_dns.id
}
