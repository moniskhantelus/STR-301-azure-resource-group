terraform {
  required_version = ">= 1.6.0"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 3.100, < 5.0"
    }
  }
}

provider "azurerm" {
  features {}
}

module "private_dns" {
  source = "../../"

  name                = "privatelink.blob.core.windows.net"
  resource_group_name = var.resource_group_name

  virtual_network_links = {
    platform = {
      name                 = "platform-vnet-link"
      virtual_network_id   = var.virtual_network_id
      registration_enabled = false
    }
  }

  tags = var.tags
}
