variable "name" {
  description = "Name of the Azure Private DNS zone, for example privatelink.blob.core.windows.net."
  type        = string

  validation {
    condition     = length(trimspace(var.name)) > 0
    error_message = "name must not be empty."
  }
}

variable "resource_group_name" {
  description = "Resource group in which the Private DNS zone is created or looked up."
  type        = string

  validation {
    condition     = length(trimspace(var.resource_group_name)) > 0
    error_message = "resource_group_name must not be empty."
  }
}

variable "create_zone" {
  description = "When true, create the Private DNS zone. When false, look up an existing zone."
  type        = bool
  default     = true
}

variable "tags" {
  description = "Tags applied to the Private DNS zone when create_zone is true."
  type        = map(string)
  default     = {}
}

variable "virtual_network_links" {
  description = <<-EOT
    Map of virtual network links. The map key is a stable Terraform key.
    name                 = optional Azure link name; defaults to the map key
    virtual_network_id   = target VNet resource ID
    registration_enabled = whether VM records in the VNet are auto-registered
    tags                 = optional tags for the VNet link
  EOT

  type = map(object({
    name                 = optional(string)
    virtual_network_id   = string
    registration_enabled = optional(bool, false)
    tags                 = optional(map(string), {})
  }))
  default = {}

  validation {
    condition = alltrue([
      for link in values(var.virtual_network_links) :
      length(trimspace(link.virtual_network_id)) > 0
    ])
    error_message = "Each virtual_network_links entry must contain a non-empty virtual_network_id."
  }
}

variable "a_records" {
  description = "Map of Private DNS A records."
  type = map(object({
    name    = string
    ttl     = optional(number, 300)
    records = list(string)
  }))
  default = {}

  validation {
    condition = alltrue([
      for r in values(var.a_records) :
      r.ttl >= 1 && length(r.records) > 0
    ])
    error_message = "Each A record must have ttl >= 1 and at least one record."
  }
}

variable "aaaa_records" {
  description = "Map of Private DNS AAAA records."
  type = map(object({
    name    = string
    ttl     = optional(number, 300)
    records = list(string)
  }))
  default = {}

  validation {
    condition = alltrue([
      for r in values(var.aaaa_records) :
      r.ttl >= 1 && length(r.records) > 0
    ])
    error_message = "Each AAAA record must have ttl >= 1 and at least one record."
  }
}

variable "cname_records" {
  description = "Map of Private DNS CNAME records."
  type = map(object({
    name   = string
    ttl    = optional(number, 300)
    record = string
  }))
  default = {}
}

variable "txt_records" {
  description = "Map of Private DNS TXT records. Each record is a list of TXT value lists."
  type = map(object({
    name    = string
    ttl     = optional(number, 300)
    records = list(list(string))
  }))
  default = {}

  validation {
    condition = alltrue([
      for r in values(var.txt_records) :
      r.ttl >= 1 && length(r.records) > 0
    ])
    error_message = "Each TXT record must have ttl >= 1 and at least one record block."
  }
}

variable "mx_records" {
  description = "Map of Private DNS MX records."
  type = map(object({
    name = string
    ttl  = optional(number, 300)
    records = list(object({
      preference = number
      exchange   = string
    }))
  }))
  default = {}
}

variable "srv_records" {
  description = "Map of Private DNS SRV records."
  type = map(object({
    name = string
    ttl  = optional(number, 300)
    records = list(object({
      priority = number
      weight   = number
      port     = number
      target   = string
    }))
  }))
  default = {}
}

variable "soa_record" {
  description = "Optional SOA override for a newly created zone. Null keeps Azure defaults."
  type = object({
    email        = string
    expire_time  = optional(number)
    minimum_ttl  = optional(number)
    refresh_time = optional(number)
    retry_time   = optional(number)
    ttl          = optional(number)
  })
  default = null
}
