# Validation / test guidance

This module is intentionally provider-backed and is expected to be validated in the platform CI pipeline.

Static checks:

```bash
terraform fmt -recursive -check
terraform init -backend=false
terraform validate
tflint --recursive
```

Recommended integration scenarios:

1. Create a new zone with one VNet link.
2. Create a new zone with multiple VNet links.
3. Reuse an existing zone with `create_zone = false`.
4. Verify `registration_enabled = false` and `true` scenarios.
5. Create A, AAAA, CNAME, TXT, MX and SRV records.
6. Remove one map entry and confirm Terraform destroys only that keyed resource.
7. Validate permissions failure is surfaced when the caller cannot link the VNet.
8. Validate duplicate Azure-side link/name conflicts fail without modifying unrelated resources.
