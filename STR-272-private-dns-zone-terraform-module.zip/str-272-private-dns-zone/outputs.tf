output "id" {
  description = "Resource ID of the Private DNS zone."
  value       = local.zone.id
}

output "name" {
  description = "Name of the Private DNS zone."
  value       = local.zone.name
}

output "resource_group_name" {
  description = "Resource group containing the Private DNS zone."
  value       = var.resource_group_name
}

output "virtual_network_link_ids" {
  description = "Map of VNet link resource IDs keyed by input key."
  value = {
    for key, link in azurerm_private_dns_zone_virtual_network_link.this :
    key => link.id
  }
}

output "a_record_ids" {
  description = "Map of A record resource IDs."
  value       = { for key, record in azurerm_private_dns_a_record.this : key => record.id }
}

output "aaaa_record_ids" {
  description = "Map of AAAA record resource IDs."
  value       = { for key, record in azurerm_private_dns_aaaa_record.this : key => record.id }
}

output "cname_record_ids" {
  description = "Map of CNAME record resource IDs."
  value       = { for key, record in azurerm_private_dns_cname_record.this : key => record.id }
}
