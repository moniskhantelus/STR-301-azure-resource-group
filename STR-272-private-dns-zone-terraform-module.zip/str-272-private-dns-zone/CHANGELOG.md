# Changelog

## 1.0.0

- Initial STR-272 Private DNS Zone module.
- Added create/reuse zone behavior.
- Added VNet links and registration control.
- Added A, AAAA, CNAME, TXT, MX and SRV records.
- Added optional SOA customization.
- Added examples, outputs and validation guidance.
